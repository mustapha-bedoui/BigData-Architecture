class Book:
    def __init__(self, book_id, title, author, available_copies):
        self.id = book_id
        self.title = title
        self.author = author
        self.available_copies = available_copies

    def __str__(self):
        return f"ID: {self.id}, Title: {self.title}, Author: {self.author}, Available Copies: {self.available_copies}"

class BookService:
    def __init__(self):
        # Simulating a database with a dictionary
        self.books = {
            1: Book(1, "Book Title 1", "Author 1", 2),
            2: Book(2, "Book Title 2", "Author 2", 1),
            # Add more books as needed
        }

    def get_book(self, book_id):
        # Retrieve book details
        return self.books.get(book_id)

    def borrow_book(self, book_id):
        # Borrow a book if available
        book = self.books.get(book_id)
        if book and book.available_copies > 0:
            book.available_copies -= 1
            return True
        return False

    def return_book(self, book_id):
        # Return a book
        book = self.books.get(book_id)
        if book:
            book.available_copies += 1
            return True
        return False
