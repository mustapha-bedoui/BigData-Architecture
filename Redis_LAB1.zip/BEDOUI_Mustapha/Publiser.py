import redis
import json

class Publisher:
    def __init__(self):
        self.connection = redis.Redis(host='localhost', port=6379, decode_responses=True)
        self.books = {}  # Simulated database using a dictionary

    def publish(self, channel: str, book_details: dict):
        self.connection.publish(channel, json.dumps(book_details))

    def save_book(self, book_details):
        self.books[book_details['id']] = book_details

    def print_all_books(self):
        if not self.books:
            print("No books available.")
            return

        print("Existing books:")
        for book_id, book in self.books.items():
            print(f"ID: {book_id}, Title: {book['title']}, Author: {book['author']}, ISBN: {book['isbn']}, Copies: {book['num_copies']}")

    def main(self):
        while True:
            print("1: Add a book\n2: Print all books\n3: Exit")
            choice = input("Choose an option: ")

            if choice == '1':
                self.add_book()
            elif choice == '2':
                self.print_all_books()
            elif choice == '3':
                break
            else:
                print("Invalid option.")

    def add_book(self):
        print("Hello! You want to add a book:")
        title = input('Title: ')
        author = input('Author: ')
        isbn = self.get_input('ISBN: ', int)
        book_id = self.get_input('ID: ', int)
        num_copies = self.get_input('Number of copies: ', int)
        keywords = input('Keywords (separated by space): ').split()

        book_details = {
            'id': book_id,
            'isbn': isbn,
            'title': title,
            'author': author,
            'num_copies': num_copies
        }

        self.save_book(book_details)  # Save the book details

        for keyword in keywords:
            self.publish(f'keyword_channel:{keyword}', book_details)
            print(f"Published book '{title}' under keyword '{keyword}'.")

    def get_input(self, prompt, input_type):
        while True:
            try:
                return input_type(input(prompt))
            except ValueError:
                print(f'Input must be of type {input_type.__name__}')

if __name__ == '__main__':
    publisher = Publisher()
    publisher.main()
