import redis
import threading
import time
from Book import BookService,Book

class Subscriber:
    def __init__(self, book_service):
        self.connection = redis.Redis(host='localhost', port=6379, decode_responses=True)
        self.pubsub = self.connection.pubsub()
        self.book_service = book_service
        self.running = True
        self.listener_thread = None

    def listen_to_channel(self):
        while self.running:
            message = self.pubsub.get_message()
            if message and message.get('type') == 'message':
                book_id = message.get('data')
                print(f"New book in {message.get('channel')} \nID: {book_id}")
                print("Type 'details' to see full book details or 'continue' to keep listening.")
                command = input("Command: ")
                if command == 'details':
                    self.show_book_details(book_id)
            # time.sleep(1)

    def show_book_details(self, book_id):
        book = self.book_service.get_book(book_id)
        if book:
            print(f"Book Details: {book}")
        else:
            print("Book not found.")

    def change_channel(self, channel):
        if self.listener_thread and self.listener_thread.is_alive():
            self.pubsub.unsubscribe()
            self.pubsub.subscribe(channel)
        else:
            self.pubsub.subscribe(channel)
            self.listener_thread = threading.Thread(target=self.listen_to_channel)
            self.listener_thread.start()

    def borrow_book(self, book_id):
        if self.book_service.borrow_book(book_id):
            print("Book successfully borrowed.")
        else:
            print("Book is not available or already borrowed.")

    def return_book(self, book_id):
        if self.book_service.return_book(book_id):
            print("Book successfully returned.")
        else:
            print("Book non existant.")

    def main(self):
        session_id = self.connection.incr('session_id')
        print(f"Session ID: {session_id}")

        while self.running:
            print('Enter a keyword to subscribe, "borrow", "return", or "exit":')
            command = input('Command: ')
            if command == 'exit':
                self.running = False
                break
            elif command.startswith('borrow'):
                book_id = input("Enter book ID to borrow: ")
                self.borrow_book(book_id)
            elif command.startswith('return'):
                book_id = input("Enter book ID to return: ")
                self.return_book(book_id)
            else:
                self.change_channel("keyword_channel:" + command)

        if self.listener_thread and self.listener_thread.is_alive():
            self.listener_thread.join()
        self.pubsub.close()

if __name__ == '__main__':
    book_service = BookService()
    subscriber = Subscriber(book_service)
    subscriber.main()
